#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'ForYou'

configs = {
	'db': {
		'host': '127.0.0.1'
	}
}